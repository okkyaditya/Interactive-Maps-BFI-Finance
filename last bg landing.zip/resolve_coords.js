/**
 * Script to resolve Google Maps short URLs and extract lat/lng coordinates for BFI Finance branches.
 * Uses a concurrency pool for high speed and caches results incrementally.
 */
const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

const CSV_URL = 'https://docs.google.com/spreadsheets/d/1WVesbsJOokoJfZ7TNZjNwiSmoG39kvvRThYQSF6krRE/export?format=csv';
const CACHE_FILE = 'coords_cache.json';
const LOG_FILE = 'C:\\Users\\Okky Aditya\\.gemini\\antigravity\\brain\\039a93da-9759-4058-91fe-bddda7f2b7a8\\.system_generated\\tasks\\task-43.log';

function fetchUrl(url, maxRedirects = 10) {
  return new Promise((resolve, reject) => {
    const protocol = url.startsWith('https') ? https : http;
    const options = {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
      },
      timeout: 15000 // Reduced timeout to 15s to keep things moving
    };

    const req = protocol.get(url, options, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        if (maxRedirects <= 0) {
          reject(new Error('Too many redirects'));
          return;
        }
        let redirectUrl = res.headers.location;
        if (redirectUrl.startsWith('/')) {
          const parsed = new URL(url);
          redirectUrl = `${parsed.protocol}//${parsed.host}${redirectUrl}`;
        }
        res.resume();
        fetchUrl(redirectUrl, maxRedirects - 1).then(resolve).catch(reject);
        return;
      }

      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        resolve({ body: data, finalUrl: url, statusCode: res.statusCode });
      });
    });

    req.on('error', reject);
    req.on('timeout', () => {
      req.destroy();
      reject(new Error('Request timeout'));
    });
  });
}

function parseCSV(text) {
  const lines = text.split('\n');
  if (lines.length < 2) return [];

  const header = parseCSVLine(lines[0]);
  const results = [];

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim().replace(/\r$/, '');
    if (!line) continue;
    const values = parseCSVLine(line);
    const obj = {};
    header.forEach((h, idx) => {
      obj[h.trim()] = (values[idx] || '').trim();
    });
    results.push(obj);
  }
  return results;
}

function parseCSVLine(line) {
  const result = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (inQuotes) {
      if (ch === '"') {
        if (i + 1 < line.length && line[i + 1] === '"') {
          current += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        current += ch;
      }
    } else {
      if (ch === '"') {
        inQuotes = true;
      } else if (ch === ',') {
        result.push(current);
        current = '';
      } else {
        current += ch;
      }
    }
  }
  result.push(current);
  return result;
}

function extractCoordinates(html, finalUrl) {
  // Pattern 1: From staticmap URL in meta tags (most reliable)
  let match = html.match(/staticmap\?center=(-?\d+\.?\d*)%2C(-?\d+\.?\d*)/);
  if (match) return { lat: parseFloat(match[1]), lng: parseFloat(match[2]) };

  // Pattern 2: @lat,lng in URL
  match = (finalUrl || '').match(/@(-?\d+\.\d+),(-?\d+\.\d+)/);
  if (match) return { lat: parseFloat(match[1]), lng: parseFloat(match[2]) };

  // Pattern 3: @lat,lng in page content
  match = html.match(/@(-?\d+\.\d+),(-?\d+\.\d+)/);
  if (match) return { lat: parseFloat(match[1]), lng: parseFloat(match[2]) };

  // Pattern 4: !3d lat !4d lng (protobuf)
  match = html.match(/!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)/);
  if (match) return { lat: parseFloat(match[1]), lng: parseFloat(match[2]) };

  // Pattern 5: center= in URL
  match = (finalUrl || '').match(/center=(-?\d+\.\d+)%2C(-?\d+\.\d+)/);
  if (match) return { lat: parseFloat(match[1]), lng: parseFloat(match[2]) };

  return null;
}

// Concurrency runner
async function mapConcurrent(items, concurrency, fn) {
  const results = [];
  let index = 0;
  const promises = [];

  async function worker() {
    while (index < items.length) {
      const curIndex = index++;
      const item = items[curIndex];
      try {
        results[curIndex] = await fn(item, curIndex);
      } catch (err) {
        results[curIndex] = { error: err };
      }
    }
  }

  for (let i = 0; i < Math.min(concurrency, items.length); i++) {
    promises.push(worker());
  }

  await Promise.all(promises);
  return results;
}

async function main() {
  console.log('Loading cache...');
  let cache = {};

  // 1. Try to load existing cache file
  if (fs.existsSync(CACHE_FILE)) {
    try {
      cache = JSON.parse(fs.readFileSync(CACHE_FILE, 'utf-8'));
      console.log(`Loaded ${Object.keys(cache).length} entries from cache file.`);
    } catch (e) {
      console.error('Error reading cache file, starting fresh:', e.message);
    }
  }

  // 2. Parse previous log if cache is empty to avoid re-querying
  if (Object.keys(cache).length === 0 && fs.existsSync(LOG_FILE)) {
    try {
      console.log('Cache file not found, but log file exists. Initializing cache from log...');
      const logContent = fs.readFileSync(LOG_FILE, 'utf-8');
      const lines = logContent.split('\n');
      let logCount = 0;
      for (const line of lines) {
        // [2/190] Cabang  Ambon... OK -> (-3.6439135, 128.2407379)
        const okMatch = line.match(/\[\d+\/\d+\]\s+Cabang\s+(.*?)\.\.\.\s+OK\s+->\s+\(([^,]+),\s*([^)]+)\)/);
        if (okMatch) {
          const name = okMatch[1].trim();
          const lat = parseFloat(okMatch[2]);
          const lng = parseFloat(okMatch[3]);
          cache[name] = { lat, lng, status: 'OK' };
          logCount++;
        }
        // [1/190] Cabang  Air Molek - Indragiri Hulu... FAILED (no coords found)
        const failMatch = line.match(/\[\d+\/\d+\]\s+Cabang\s+(.*?)\.\.\.\s+FAILED/);
        if (failMatch) {
          const name = failMatch[1].trim();
          cache[name] = { status: 'FAILED' };
          logCount++;
        }
      }
      console.log(`Successfully recovered ${logCount} entries from the log.`);
      fs.writeFileSync(CACHE_FILE, JSON.stringify(cache, null, 2), 'utf-8');
    } catch (e) {
      console.error('Error parsing log file:', e.message);
    }
  }

  console.log('Fetching CSV data from Google Sheets...');
  const csvResponse = await fetchUrl(CSV_URL);
  const rows = parseCSV(csvResponse.body);
  console.log(`Found ${rows.length} branches total. Resolving coordinates concurrently...\n`);

  const results = [];
  const failed = [];
  const toResolve = [];

  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    const name = (row['Nama Cabang'] || '').trim();
    const phone = row['Telepon'] || '';
    const city = row['Kabupaten/Kota'] || '';
    const address = row['Alamat'] || '';
    const mapsUrl = (row['Petunjuk Arah URL'] || '').trim();
    
    // Determine syariah status based on the branch name (contains "syariah" case-insensitive)
    const isSyariah = name.toLowerCase().includes('syariah');

    if (!mapsUrl) {
      failed.push({ name, mapsUrl, reason: 'no URL' });
      continue;
    }

    // Check if we already have it in the cache and it was successful
    if (cache[name] && cache[name].status === 'OK' && cache[name].lat && cache[name].lng) {
      results.push({
        name, phone, city, address, mapsUrl,
        syariah: isSyariah,
        lat: cache[name].lat,
        lng: cache[name].lng
      });
      continue;
    }

    toResolve.push({
      index: i + 1,
      name, phone, city, address, mapsUrl, syariah: isSyariah
    });
  }

  console.log(`Using cached data for ${results.length} branches. Need to resolve ${toResolve.length} branches.\n`);

  // Concurrency limit of 12 requests
  await mapConcurrent(toResolve, 12, async (item, idx) => {
    const { name, phone, city, address, mapsUrl, syariah, index } = item;
    try {
      const response = await fetchUrl(mapsUrl);
      const coords = extractCoordinates(response.body, response.finalUrl);

      if (coords && coords.lat && coords.lng) {
        console.log(`[${index}/${rows.length}] ${name} ... OK -> (${coords.lat}, ${coords.lng})`);
        
        // Update cache memory
        cache[name] = { lat: coords.lat, lng: coords.lng, status: 'OK' };
        
        results.push({
          name, phone, city, address, mapsUrl,
          syariah: syariah,
          lat: coords.lat,
          lng: coords.lng
        });
      } else {
        console.log(`[${index}/${rows.length}] ${name} ... FAILED (no coords found)`);
        cache[name] = { status: 'FAILED' };
        failed.push({ name, mapsUrl, reason: 'no coords' });
      }
    } catch (err) {
      console.log(`[${index}/${rows.length}] ${name} ... ERROR: ${err.message}`);
      cache[name] = { status: 'FAILED' };
      failed.push({ name, mapsUrl, reason: err.message });
    }

    // Save cache incrementally on every 5 completed requests or at the end
    if (idx % 5 === 0 || idx === toResolve.length - 1) {
      fs.writeFileSync(CACHE_FILE, JSON.stringify(cache, null, 2), 'utf-8');
    }
  });

  console.log(`\n=== RESULTS ===`);
  console.log(`Successfully resolved: ${results.length}`);
  console.log(`Failed: ${failed.length}`);

  if (failed.length > 0) {
    console.log('\nFailed branches (could not find coordinates):');
    failed.forEach(f => console.log(`  - ${f.name}: ${f.reason} (${f.mapsUrl})`));
  }

  // Generate JavaScript data file
  let jsData = '// Auto-generated BFI Finance branch data with coordinates\n';
  jsData += `// Generated on: ${new Date().toISOString()}\n`;
  jsData += `// Total branches: ${results.length} (resolved) + ${failed.length} (failed)\n\n`;
  jsData += 'const BRANCHES = [\n';

  for (const branch of results) {
    jsData += `  ${JSON.stringify(branch)},\n`;
  }

  jsData += '];\n';

  const outputPath = 'branches_data.js';
  fs.writeFileSync(outputPath, jsData, 'utf-8');
  console.log(`\nJavaScript data saved to: ${outputPath}`);
}

main().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
