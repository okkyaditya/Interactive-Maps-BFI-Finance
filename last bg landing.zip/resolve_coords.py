"""
Script to resolve Google Maps short URLs and extract lat/lng coordinates for BFI Finance branches.
Outputs a JavaScript file with all branch data including coordinates.
"""
import requests
import re
import time
import json
import csv
import io
import sys

# CSV data from the Google Sheets
CSV_URL = "https://docs.google.com/spreadsheets/d/1WVesbsJOokoJfZ7TNZjNwiSmoG39kvvRThYQSF6krRE/export?format=csv"

def get_coordinates_from_url(short_url):
    """Resolve a Google Maps short URL and extract lat/lng coordinates."""
    if not short_url or short_url.strip() == '':
        return None, None
    
    short_url = short_url.strip()
    
    session = requests.Session()
    session.headers.update({
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    })
    
    try:
        response = session.get(short_url, allow_redirects=True, timeout=30)
        content = response.text
        final_url = response.url
        
        # Pattern 1: From staticmap URL in meta tags (most reliable)
        match = re.search(r'staticmap\?center=(-?\d+\.?\d*)%2C(-?\d+\.?\d*)', content)
        if match:
            return float(match.group(1)), float(match.group(2))
        
        # Pattern 2: @lat,lng in URL
        match = re.search(r'@(-?\d+\.\d+),(-?\d+\.\d+)', final_url)
        if match:
            return float(match.group(1)), float(match.group(2))
        
        # Pattern 3: @lat,lng in page content
        match = re.search(r'@(-?\d+\.\d+),(-?\d+\.\d+)', content)
        if match:
            return float(match.group(1)), float(match.group(2))
        
        # Pattern 4: center= in URL
        match = re.search(r'center=(-?\d+\.\d+)%2C(-?\d+\.\d+)', final_url)
        if match:
            return float(match.group(1)), float(match.group(2))
        
        # Pattern 5: ll= in URL  
        match = re.search(r'll=(-?\d+\.\d+),(-?\d+\.\d+)', final_url)
        if match:
            return float(match.group(1)), float(match.group(2))
            
        # Pattern 6: from pb parameter (encoded protobuf)
        match = re.search(r'!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)', content)
        if match:
            return float(match.group(1)), float(match.group(2))
            
        print(f"  WARNING: Could not extract coordinates from URL")
        return None, None
        
    except Exception as e:
        print(f"  ERROR: {e}")
        return None, None


def main():
    print("Fetching CSV data from Google Sheets...")
    response = requests.get(CSV_URL, timeout=30)
    response.encoding = 'utf-8'
    csv_text = response.text
    
    reader = csv.DictReader(io.StringIO(csv_text))
    branches = []
    
    for row in reader:
        branches.append({
            'name': row.get('Nama Cabang', '').strip(),
            'phone': row.get('Telepon', '').strip(),
            'city': row.get('Kabupaten/Kota', '').strip(),
            'address': row.get('Alamat', '').strip(),
            'maps_url': row.get('Petunjuk Arah URL', '').strip(),
            'syariah': row.get('Unit Syariah', '').strip(),
        })
    
    print(f"Found {len(branches)} branches. Resolving coordinates...")
    
    results = []
    failed = []
    
    for i, branch in enumerate(branches):
        print(f"[{i+1}/{len(branches)}] {branch['name']}...", end=" ")
        
        lat, lng = get_coordinates_from_url(branch['maps_url'])
        
        if lat is not None and lng is not None:
            print(f"OK -> ({lat}, {lng})")
            branch['lat'] = lat
            branch['lng'] = lng
            results.append(branch)
        else:
            print(f"FAILED")
            failed.append(branch)
        
        # Rate limiting
        time.sleep(0.5)
    
    print(f"\n=== RESULTS ===")
    print(f"Successfully resolved: {len(results)}")
    print(f"Failed: {len(failed)}")
    
    if failed:
        print("\nFailed branches:")
        for b in failed:
            print(f"  - {b['name']}: {b['maps_url']}")
    
    # Generate JavaScript data file
    js_data = "// Auto-generated BFI Finance branch data with coordinates\n"
    js_data += f"// Generated on: {time.strftime('%Y-%m-%d %H:%M:%S')}\n"
    js_data += f"// Total branches: {len(results)} (resolved) + {len(failed)} (failed)\n\n"
    js_data += "const BRANCHES = [\n"
    
    for branch in results:
        entry = {
            'name': branch['name'],
            'phone': branch['phone'],
            'city': branch['city'],
            'address': branch['address'],
            'mapsUrl': branch['maps_url'],
            'syariah': branch['syariah'] == 'Ada',
            'lat': branch['lat'],
            'lng': branch['lng'],
        }
        js_data += f"  {json.dumps(entry, ensure_ascii=False)},\n"
    
    js_data += "];\n"
    
    output_path = "branches_data.js"
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(js_data)
    
    print(f"\nJavaScript data saved to: {output_path}")


if __name__ == '__main__':
    main()
